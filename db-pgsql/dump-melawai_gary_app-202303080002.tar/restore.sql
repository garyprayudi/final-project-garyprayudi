--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1
-- Dumped by pg_dump version 15.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'WIN1252';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE melawai_gary_app;
--
-- Name: melawai_gary_app; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE melawai_gary_app WITH TEMPLATE = template0 ENCODING = 'WIN1252' LOCALE_PROVIDER = libc LOCALE = 'English_Indonesia.1252';


ALTER DATABASE melawai_gary_app OWNER TO postgres;

\connect melawai_gary_app

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'WIN1252';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.access_token (
    id bigint NOT NULL,
    token text NOT NULL,
    expired_at timestamp(0) without time zone NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.access_token OWNER TO postgres;

--
-- Name: access_token_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.access_token_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.access_token_id_seq OWNER TO postgres;

--
-- Name: access_token_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.access_token_id_seq OWNED BY public.access_token.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO postgres;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.failed_jobs_id_seq OWNER TO postgres;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: m_customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.m_customers (
    id bigint NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(150) NOT NULL,
    birth_date date NOT NULL,
    address text NOT NULL,
    city character varying(40) NOT NULL,
    no_handphone character varying(20) NOT NULL,
    email character varying(100) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.m_customers OWNER TO postgres;

--
-- Name: m_customers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.m_customers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.m_customers_id_seq OWNER TO postgres;

--
-- Name: m_customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.m_customers_id_seq OWNED BY public.m_customers.id;


--
-- Name: m_materials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.m_materials (
    id bigint NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(200) NOT NULL,
    price numeric(10,2) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.m_materials OWNER TO postgres;

--
-- Name: m_materials_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.m_materials_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.m_materials_id_seq OWNER TO postgres;

--
-- Name: m_materials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.m_materials_id_seq OWNED BY public.m_materials.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO postgres;

--
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.personal_access_tokens OWNER TO postgres;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.personal_access_tokens_id_seq OWNER TO postgres;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


--
-- Name: t_receipts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_receipts (
    id bigint NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(150) NOT NULL,
    customer_id integer NOT NULL,
    spheris_right character varying(10) NOT NULL,
    spheris_left character varying(10) NOT NULL,
    cylinder_right character varying(10) NOT NULL,
    cylinder_left character varying(10) NOT NULL,
    addition_right character varying(10) NOT NULL,
    addition_left character varying(10) NOT NULL,
    axis_right character varying(10) NOT NULL,
    axis_left character varying(10) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.t_receipts OWNER TO postgres;

--
-- Name: t_receipts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_receipts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.t_receipts_id_seq OWNER TO postgres;

--
-- Name: t_receipts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_receipts_id_seq OWNED BY public.t_receipts.id;


--
-- Name: t_sod; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_sod (
    id bigint NOT NULL,
    so_h_id integer NOT NULL,
    material_id integer NOT NULL,
    material_code character varying(10) NOT NULL,
    material_name character varying(200) NOT NULL,
    material_price numeric(10,2) NOT NULL,
    qty integer NOT NULL
);


ALTER TABLE public.t_sod OWNER TO postgres;

--
-- Name: t_sod_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_sod_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.t_sod_id_seq OWNER TO postgres;

--
-- Name: t_sod_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_sod_id_seq OWNED BY public.t_sod.id;


--
-- Name: t_soh; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_soh (
    id bigint NOT NULL,
    invoice character varying(16) NOT NULL,
    customer_id integer NOT NULL,
    date date NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.t_soh OWNER TO postgres;

--
-- Name: t_soh_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_soh_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.t_soh_id_seq OWNER TO postgres;

--
-- Name: t_soh_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_soh_id_seq OWNED BY public.t_soh.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    username character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: access_token id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_token ALTER COLUMN id SET DEFAULT nextval('public.access_token_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: m_customers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.m_customers ALTER COLUMN id SET DEFAULT nextval('public.m_customers_id_seq'::regclass);


--
-- Name: m_materials id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.m_materials ALTER COLUMN id SET DEFAULT nextval('public.m_materials_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


--
-- Name: t_receipts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_receipts ALTER COLUMN id SET DEFAULT nextval('public.t_receipts_id_seq'::regclass);


--
-- Name: t_sod id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_sod ALTER COLUMN id SET DEFAULT nextval('public.t_sod_id_seq'::regclass);


--
-- Name: t_soh id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_soh ALTER COLUMN id SET DEFAULT nextval('public.t_soh_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: access_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3432.dat

--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3428.dat

--
-- Data for Name: m_customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3436.dat

--
-- Data for Name: m_materials; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3434.dat

--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3423.dat

--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3426.dat

--
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3430.dat

--
-- Data for Name: t_receipts; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3438.dat

--
-- Data for Name: t_sod; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3442.dat

--
-- Data for Name: t_soh; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3440.dat

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3425.dat

--
-- Name: access_token_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.access_token_id_seq', 12, true);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: m_customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.m_customers_id_seq', 11, true);


--
-- Name: m_materials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.m_materials_id_seq', 100, true);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migrations_id_seq', 10, true);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.personal_access_tokens_id_seq', 1, false);


--
-- Name: t_receipts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_receipts_id_seq', 10, true);


--
-- Name: t_sod_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_sod_id_seq', 100, true);


--
-- Name: t_soh_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_soh_id_seq', 10, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 10, true);


--
-- Name: access_token access_token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_token
    ADD CONSTRAINT access_token_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: m_customers m_customers_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.m_customers
    ADD CONSTRAINT m_customers_code_unique UNIQUE (code);


--
-- Name: m_customers m_customers_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.m_customers
    ADD CONSTRAINT m_customers_email_unique UNIQUE (email);


--
-- Name: m_customers m_customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.m_customers
    ADD CONSTRAINT m_customers_pkey PRIMARY KEY (id);


--
-- Name: m_materials m_materials_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.m_materials
    ADD CONSTRAINT m_materials_code_unique UNIQUE (code);


--
-- Name: m_materials m_materials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.m_materials
    ADD CONSTRAINT m_materials_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


--
-- Name: t_receipts t_receipts_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_receipts
    ADD CONSTRAINT t_receipts_code_unique UNIQUE (code);


--
-- Name: t_receipts t_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_receipts
    ADD CONSTRAINT t_receipts_pkey PRIMARY KEY (id);


--
-- Name: t_sod t_sod_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_sod
    ADD CONSTRAINT t_sod_pkey PRIMARY KEY (id);


--
-- Name: t_soh t_soh_invoice_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_soh
    ADD CONSTRAINT t_soh_invoice_unique UNIQUE (invoice);


--
-- Name: t_soh t_soh_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_soh
    ADD CONSTRAINT t_soh_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: m_customers_id_code_name_city_no_handphone_email_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX m_customers_id_code_name_city_no_handphone_email_index ON public.m_customers USING btree (id, code, name, city, no_handphone, email);


--
-- Name: m_materials_id_code_name_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX m_materials_id_code_name_index ON public.m_materials USING btree (id, code, name);


--
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


--
-- Name: t_receipts_id_code_customer_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX t_receipts_id_code_customer_id_index ON public.t_receipts USING btree (id, code, customer_id);


--
-- Name: t_sod_id_so_h_id_material_id_material_code_material_name_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX t_sod_id_so_h_id_material_id_material_code_material_name_index ON public.t_sod USING btree (id, so_h_id, material_id, material_code, material_name);


--
-- Name: t_soh_id_invoice_customer_id_date_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX t_soh_id_invoice_customer_id_date_index ON public.t_soh USING btree (id, invoice, customer_id, date);


--
-- Name: t_receipts t_receipts_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_receipts
    ADD CONSTRAINT t_receipts_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.m_customers(id);


--
-- Name: t_sod t_sod_so_h_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_sod
    ADD CONSTRAINT t_sod_so_h_id_foreign FOREIGN KEY (so_h_id) REFERENCES public.t_soh(id);


--
-- Name: t_soh t_soh_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_soh
    ADD CONSTRAINT t_soh_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.m_customers(id);


--
-- PostgreSQL database dump complete
--

